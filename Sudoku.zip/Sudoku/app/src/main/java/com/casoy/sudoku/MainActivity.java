package com.casoy.sudoku;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

import com.casoy.sudoku.R;

public class MainActivity extends Activity {
  private SudokuPuzzle savedPuzzle;
  private HighScore highScore;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);

    getActionBar()
        .setBackgroundDrawable(getResources().getDrawable(R.drawable.red_action_bar, null));
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.menu_main, menu);
    return super.onCreateOptionsMenu(menu);
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case R.id.about_us:
        Intent intent = new Intent(this, AboutUsActivity.class);
        startActivity(intent);
        return true;
      default:
        return super.onOptionsItemSelected(item);
    }
  }

  @Override
  public void onResume() {
    super.onResume();
    savedPuzzle = null;

    try {
      FileInputStream gridFileInput = openFileInput("puzzle.grid");
      ObjectInputStream gridObjectInput = new ObjectInputStream(gridFileInput);

      savedPuzzle = (SudokuPuzzle) gridObjectInput.readObject();

      gridFileInput.close();
      gridObjectInput.close();
    } catch (Exception e) {
      savedPuzzle = null;
      e.printStackTrace();
    }

    try {
      FileInputStream highScoreFileInput = openFileInput("highScore.hs");
      ObjectInputStream highScoreObjectInput = new ObjectInputStream(highScoreFileInput);

      highScore = (HighScore) highScoreObjectInput.readObject();

      highScoreFileInput.close();
      highScoreObjectInput.close();
    } catch (Exception e) {
      highScore = new HighScore();
      e.printStackTrace();
    }

    View continueButton = findViewById(R.id.continue_button);

    if (savedPuzzle != null) {
      if (savedPuzzle.isEasy()) {
        continueButton.setBackgroundResource(SudokuColor.GREEN.getBackgroundId());
      } else if (savedPuzzle.isMedium()) {
        continueButton.setBackgroundResource(SudokuColor.RED.getBackgroundId());
      } else if (savedPuzzle.isAdvance()) {
        continueButton.setBackgroundResource(SudokuColor.BLUE.getBackgroundId());
      } else if (savedPuzzle.isMaster()) {
        continueButton.setBackgroundResource(SudokuColor.YELLOW.getBackgroundId());
      } else if (savedPuzzle.isLegendary()) {
        continueButton.setBackgroundResource(SudokuColor.GREY.getBackgroundId());
      }
    } else {
      continueButton.setBackgroundResource(SudokuColor.BLACK.getBackgroundId());
    }
  }

  public void continueGame(View view) {
    if (savedPuzzle != null) {
      Intent intent = new Intent(this, SolvingActivity.class);
      intent.putExtra(SudokuPuzzle.EXTRA_PUZZLE, savedPuzzle);
      intent.putExtra(HighScore.EXTRA_HIGH_SCORE, highScore);
      startActivity(intent);
    } else {
      Toast.makeText(this, "No Saved Progress", Toast.LENGTH_LONG).show();
    }
  }

  public void highScore(View view) {
    Intent intent = new Intent(this, HighScoreActivity.class);
    intent.putExtra(HighScore.EXTRA_HIGH_SCORE, highScore);
    startActivity(intent);
  }

  public void newGame(View view) {
    Intent intent = new Intent(this, NewGameActivity.class);
    intent.putExtra(HighScore.EXTRA_HIGH_SCORE, highScore);
    startActivity(intent);
  }

  public void rules(View view) {
    Intent intent = new Intent(this, RulesActivity.class);
    startActivity(intent);
  }
}
