package com.casoy.sudoku;

import java.io.Serializable;

public class SudokuCell implements Serializable {
  private final static long serialVersionUID = 1L;
  private SudokuRow row;
  private SudokuColumn column;
  private SudokuBlock block;
  private int val;
  private SudokuColor color;
  private boolean[] pencilMarks;
  private SudokuColor[] pencilColors;

  public SudokuCell() {
    pencilMarks = new boolean[9];
    pencilColors = new SudokuColor[9];

    for (int i = 0; i < 9; i++) {
      pencilMarks[i] = false;
      pencilColors[i] = SudokuColor.GREY;
    }
  }

  public void setValue(int val) {
    this.val = val;
    
    for (int i = 0; i < 9; i++) {
      pencilMarks[i] = false;
      pencilColors[i] = SudokuColor.GREY;
    }
  }

  public int getValue() {
    return val;
  }

  public void pencilMark(int num) {
    pencilMarks[num - 1] = !pencilMarks[num - 1];
    color = SudokuColor.GREY;
    val = 0;
  }

  public boolean isMarkedAt(int num) {
    return pencilMarks[num - 1];
  }

  public boolean hasPencilMark() {
    for (boolean pencil : pencilMarks) {
      if (pencil) {
        return true;
      }
    }

    return false;
  }

  public void setRow(SudokuRow row) {
    this.row = row;
  }

  public void setColumn(SudokuColumn column) {
    this.column = column;
  }

  public void setBlock(SudokuBlock block) {
    this.block = block;
  }

  public boolean isAvailable(int val) {
    return row.isAvailable(val) && column.isAvailable(val) && block.isAvailable(val);
  }

  public int getRowNumber() {
    return row.getNumber();
  }

  public int getColumnNumber() {
    return column.getNumber();
  }

  public boolean canBeDig(int minBound) {
    return row.getGivenCount() > minBound
        && column.getGivenCount() > minBound
        && block.getGivenCount() > minBound;
  }

  void setColor(SudokuColor color) {
    this.color = color;
  }

  SudokuColor getColor() {
    return color;
  }

  void setPencilColor(int num, SudokuColor color) {
    pencilColors[num - 1] = color;
  }

  SudokuColor getPencilColor(int num) {
    return pencilColors[num - 1];
  }
}
