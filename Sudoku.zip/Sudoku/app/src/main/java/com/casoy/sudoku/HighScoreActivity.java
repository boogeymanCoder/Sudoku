package com.casoy.sudoku;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class HighScoreActivity extends Activity {
  private HighScore highScore;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_high_score);

    highScore = (HighScore) getIntent().getSerializableExtra(HighScore.EXTRA_HIGH_SCORE);

    getActionBar()
        .setBackgroundDrawable(getResources().getDrawable(R.drawable.blue_action_bar, null));

    TextView easy = (TextView) findViewById(R.id.easy_high_score);
    TextView medium = (TextView) findViewById(R.id.medium_high_score);
    TextView advance = (TextView) findViewById(R.id.advance_high_score);
    TextView master = (TextView) findViewById(R.id.master_high_score);
    TextView legendary = (TextView) findViewById(R.id.legendary_high_score);
    
    easy.setText(formatMillis(highScore.getEasyHighScore()));
    medium.setText(formatMillis(highScore.getMediumHighScore()));
    advance.setText(formatMillis(highScore.getAdvanceHighScore()));
    master.setText(formatMillis(highScore.getMasterHighScore()));
    legendary.setText(formatMillis(highScore.getLegendaryHighScore()));
  }

  private String formatMillis(long milli) {
    String result = "";

    int sec = (int) (milli / 1000);
    int min = sec / 60;
    sec = sec % 60;
    int hour = min / 60;
    min = min % 60;

    if (hour != 0) {
      result = result + String.format("%02d:", hour);
    }
    result = result + String.format("%02d:%02d", min, sec);
    
    return result;
  }
}
