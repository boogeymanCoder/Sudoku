package com.casoy.sudoku;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class PencilCellFragment extends CellFragment {
  private boolean[] pencilMarks;
  private SudokuColor[] pencilMarkColors;

  public PencilCellFragment() {
    pencilMarks = new boolean[9];
    pencilMarkColors = new SudokuColor[9];
    for (int i = 0; i < 9; i++) {
      pencilMarks[i] = false;
      pencilMarkColors[i] = SudokuColor.GREY;
    }
  }

  @Override
  public View onCreateView(
      LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    return inflater.inflate(R.layout.fragment_pencil_cell, container, false);
  }

  public void onStart() {
    super.onStart();

    View view = getView();
    if (view != null) {
      TextView[] pencils = {
        (TextView) view.findViewById(R.id.pencil1),
        (TextView) view.findViewById(R.id.pencil2),
        (TextView) view.findViewById(R.id.pencil3),
        (TextView) view.findViewById(R.id.pencil4),
        (TextView) view.findViewById(R.id.pencil5),
        (TextView) view.findViewById(R.id.pencil6),
        (TextView) view.findViewById(R.id.pencil7),
        (TextView) view.findViewById(R.id.pencil8),
        (TextView) view.findViewById(R.id.pencil9)
      };

      for (int i = 0; i < 9; i++) {
        if (pencilMarks[i]) {
          pencils[i].setTextColor(Color.parseColor(pencilMarkColors[i].getHex()));
          pencils[i].setText("" + (i + 1));
        }
      }

      View cellContainer = view.findViewById(R.id.cell_container);
      cellContainer.setTag(this);
      
      if (isSelected()) {
        cellContainer.setBackground(getResources().getDrawable(R.drawable.selected_border, null));
      }
    }
  }

  public void pencilMark(int num) {
    pencilMarks[num - 1] = true;
  }

  public void setPencilMarkColor(int num, SudokuColor color) {
    pencilMarkColors[num - 1] = color;
  }
}
