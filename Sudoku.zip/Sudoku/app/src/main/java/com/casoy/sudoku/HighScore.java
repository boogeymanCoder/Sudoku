package com.casoy.sudoku;

import java.io.Serializable;

public class HighScore implements Serializable {
  private long easy;
  private long medium;
  private long advance;
  private long master;
  private long legendary;
  private static final long serialVersionUID = 1L;
  public static final String EXTRA_HIGH_SCORE = "extra_high_score";
  
  public boolean examine(SudokuPuzzle puzzle) {
    if (puzzle.isEasy() && (puzzle.getTime() < easy || puzzle.getTime() > 0)) {
      easy = puzzle.getTime();
      return true;
    } else if (puzzle.isMedium() && (puzzle.getTime() < medium || puzzle.getTime() > 0)) {
      medium = puzzle.getTime();
      return true;
    } else if (puzzle.isAdvance() && (puzzle.getTime() < advance || puzzle.getTime() > 0)) {
      advance = puzzle.getTime();
      return true;
    } else if (puzzle.isMaster() && (puzzle.getTime() < master || puzzle.getTime() > 0)) {
      master = puzzle.getTime();
      return true;
    } else if (puzzle.isLegendary() && (puzzle.getTime() < easy || puzzle.getTime() > 0)) {
      legendary = puzzle.getTime();
      return true;
    } else {
      return false;
    }
  }
  
  public long getEasyHighScore() {
    return easy;
  }
  
  public long getMediumHighScore() {
    return medium;
  }
  
  public long getAdvanceHighScore() {
    return advance;
  }
  
  public long getMasterHighScore() {
    return master;
  }
  
  public long getLegendaryHighScore() {
    return legendary;
  }
}
