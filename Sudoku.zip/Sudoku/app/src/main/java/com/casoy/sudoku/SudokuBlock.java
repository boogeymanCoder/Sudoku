package com.casoy.sudoku;

import java.io.Serializable;

public class SudokuBlock extends SudokuContainer implements Serializable {
  private final static long serialVersionUID = 1L;
  @Override
  public void addCell(SudokuCell cell) {
    super.addCell(cell);
    cell.setBlock(this);
  }
}
