package com.casoy.sudoku;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class BlankCellFragment extends CellFragment {
  private int val;
  private SudokuColor color = SudokuColor.GREY;

  @Override
  public View onCreateView(
      LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    return inflater.inflate(R.layout.fragment_blank_cell, container, false);
  }

  @Override
  public void onStart() {
    super.onStart();

    View view = getView();

    if (view != null) {
      TextView valueText = (TextView) view.findViewById(R.id.value_text);
      valueText.setTag(this);

      if (val != 0) {
        valueText.setText("" + val);
        valueText.setTextColor(Color.parseColor(color.getHex()));
      }

      if (isSelected()) {
        valueText.setBackground(getResources().getDrawable(R.drawable.selected_border, null));
      }
    }
  }

  public void setVal(int val) {
    this.val = val;
  }

  public void setColor(SudokuColor color) {
    this.color = color;
  }
}
