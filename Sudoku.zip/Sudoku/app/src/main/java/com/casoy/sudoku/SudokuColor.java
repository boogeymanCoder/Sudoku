package com.casoy.sudoku;

import java.io.Serializable;

public class SudokuColor implements Serializable {
  private static final long serialVersionUID = 1L;
  private String name;
  private String hex;
  private int shapeId;
  private int backgroundId;

  public static final SudokuColor WHITE =
      new SudokuColor("white", "#ffffff", R.drawable.white, R.drawable.background_white);
  public static final SudokuColor BLACK =
      new SudokuColor("black", "#000000", R.drawable.black, R.drawable.background_black);
  public static final SudokuColor GREY =
      new SudokuColor("grey", "#757575", R.drawable.grey, R.drawable.background_grey);
  public static final SudokuColor RED =
      new SudokuColor("red", "#A10000", R.drawable.red, R.drawable.background_red);
  public static final SudokuColor YELLOW =
      new SudokuColor("yellow", "#FCD462", R.drawable.yellow, R.drawable.background_yellow);
  public static final SudokuColor GREEN =
      new SudokuColor("green", "#44C4A1", R.drawable.green, R.drawable.background_green);
  public static final SudokuColor BLUE =
      new SudokuColor("blue", "#2782DB", R.drawable.blue, R.drawable.background_blue);

  private SudokuColor(String name, String hex, int shapeId, int backgroundId) {
    this.name = name;
    this.hex = hex;
    this.shapeId = shapeId;
    this.backgroundId = backgroundId;
  }

  @Override
  public boolean equals(Object other) {
    SudokuColor color = (SudokuColor) other;
    return name.equals(color.getName())
        && hex.equals(color.getHex())
        && shapeId == color.getShapeId()
        && backgroundId == color.getBackgroundId();
  }

  public String getName() {
    return name;
  }

  public String getHex() {
    return hex;
  }

  public int getShapeId() {
    return shapeId;
  }

  public int getBackgroundId() {
    return backgroundId;
  }
}
