package com.casoy.sudoku;

import java.io.Serializable;

public abstract class SudokuContainer implements Serializable {
  private final static long serialVersionUID = 1L;
  private SudokuCell[] cells;
  private int index;

  public SudokuContainer() {
    cells = new SudokuCell[9];
  }

  public boolean validate() {
    for (int i = 0; i < 9; i++) {
      int iVal = cells[i].getValue();

      if (iVal != 0) {
        for (int j = i + 1; j < 9; j++) {
          int jVal = cells[j].getValue();

          if (iVal == jVal && jVal != 0) {
            return false;
          }
        }
      } else {
        return false;
      }
    }

    return true;
  }

  public boolean isAvailable(int val) {
    for (SudokuCell cell : cells) {
      if (cell.getValue() == val) {
        return false;
      }
    }

    return true;
  }

  public void addCell(SudokuCell cell) {
    cells[index] = cell;
    index++;
  }

  public int getGivenCount() {
    int count = 0;

    for (SudokuCell cell : cells) {
      if (cell.getValue() != 0) {
        count++;
      }
    }

    return count;
  }
}
