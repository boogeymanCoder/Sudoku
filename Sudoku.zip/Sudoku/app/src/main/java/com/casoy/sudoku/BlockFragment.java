package com.casoy.sudoku;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class BlockFragment extends Fragment {
  private CellFragment[][] cellFragments;
  private int row;
  private int column;

  public BlockFragment() {
    cellFragments = new CellFragment[3][3];
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        cellFragments[i][j] = new BlankCellFragment();
      }
    }
  }

  @Override
  public View onCreateView(
      LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    return inflater.inflate(R.layout.fragment_block, container, false);
  }

  @Override
  public void onStart() {
    super.onStart();

    View view = getView();

    if (view != null) {
      FragmentTransaction ft = getChildFragmentManager().beginTransaction();
      ft.replace(R.id.cell00, cellFragments[0][0]);
      ft.replace(R.id.cell01, cellFragments[0][1]);
      ft.replace(R.id.cell02, cellFragments[0][2]);
      ft.replace(R.id.cell10, cellFragments[1][0]);
      ft.replace(R.id.cell11, cellFragments[1][1]);
      ft.replace(R.id.cell12, cellFragments[1][2]);
      ft.replace(R.id.cell20, cellFragments[2][0]);
      ft.replace(R.id.cell21, cellFragments[2][1]);
      ft.replace(R.id.cell22, cellFragments[2][2]);
      ft.commit();
    }

    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        cellFragments[i][j].setRow(row * 3 + i);
        cellFragments[i][j].setColumn(column * 3 + j);
      }
    }
  }

  public void setRow(int row) {
    this.row = row;
  }

  public void setColumn(int column) {
    this.column = column;
  }

  public void pencilMark(int row, int col, int num) {
    if (!(cellFragments[row][col] instanceof PencilCellFragment)) {
      cellFragments[row][col] = new PencilCellFragment();
    }

    ((PencilCellFragment) cellFragments[row][col]).pencilMark(num);
  }

  /*public void setVal(int row, int col, int val) {
    cellFragments[row][col] = new BlankCellFragment();
    ((BlankCellFragment) cellFragments[row][col]).setVal(val);
  }*/

  public void setGiven(int row, int col, int val) {
    cellFragments[row][col] = new GivenCellFragment();
    ((GivenCellFragment) cellFragments[row][col]).setGivenVal(val);
  }

  public void setPencilColor(int row, int col, int num, SudokuColor color) {
    if (!(cellFragments[row][col] instanceof PencilCellFragment)) {
      cellFragments[row][col] = new PencilCellFragment();
    }

    ((PencilCellFragment) cellFragments[row][col]).setPencilMarkColor(num, color);
  }

  /*public void setColor(int row, int col, SudokuColor color) {
    if (!(cellFragments[row][col] instanceof BlankCellFragment)) {
      cellFragments[row][col] = new BlankCellFragment();
    }

    ((BlankCellFragment) cellFragments[row][col]).setColor(color);
  }*/
  
  public void setBlankCell(int row, int col, int val, SudokuColor color) {
    cellFragments[row][col] = new BlankCellFragment();
    ((BlankCellFragment)cellFragments[row][col]).setVal(val);
    ((BlankCellFragment)cellFragments[row][col]).setColor(color);
  }

  public void select(int row, int col) {
    cellFragments[row][col].select();
  }
}
