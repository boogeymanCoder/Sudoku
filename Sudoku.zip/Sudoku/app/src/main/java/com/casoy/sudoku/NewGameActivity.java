package com.casoy.sudoku;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class NewGameActivity extends Activity {
  private HighScore highScore;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_new_game);
    getActionBar()
        .setBackgroundDrawable(getResources().getDrawable(R.drawable.yellow_action_bar, null));
        
    highScore = (HighScore) getIntent().getSerializableExtra(HighScore.EXTRA_HIGH_SCORE);
  }

  public void makePuzzle(View view) {
    SudokuPuzzle puzzle = null;

    switch (view.getId()) {
      case R.id.easy:
        puzzle = new SudokuPuzzle(SudokuPuzzle.Level.EASY);
        break;
      case R.id.medium:
        puzzle = new SudokuPuzzle(SudokuPuzzle.Level.MEDIUM);
        break;
      case R.id.advance:
        puzzle = new SudokuPuzzle(SudokuPuzzle.Level.ADVANCE);
        break;
      case R.id.master:
        puzzle = new SudokuPuzzle(SudokuPuzzle.Level.MASTER);
        break;
      case R.id.legendary:
        puzzle = new SudokuPuzzle(SudokuPuzzle.Level.LEGENDARY);
        break;
    }

    Intent intent = new Intent(this, SolvingActivity.class);
    intent.putExtra(SudokuPuzzle.EXTRA_PUZZLE, puzzle);
    intent.putExtra(HighScore.EXTRA_HIGH_SCORE, highScore);
    startActivity(intent);
  }
}
