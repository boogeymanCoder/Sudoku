package com.casoy.sudoku;

import android.app.Activity;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.os.Handler;
import android.os.SystemClock;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class SolvingActivity extends Activity {
  private SudokuPuzzle puzzle;
  private GridFragment gridFragment;
  private InputFragment input;
  private HighScore highScore;

  private TextView timerText;
  private Handler timeHandler = new Handler();
  private long startTime = 0L;
  private long time = 0L;
  private Runnable updateTimerThread =
      new Runnable() {
        public void run() {

          if (!puzzle.validate()) {
            time = SystemClock.uptimeMillis() - startTime;
          }

          int sec = (int) (time / 1000);
          int min = sec / 60;
          sec = sec % 60;
          int hour = min / 60;
          min = min % 60;

          String timeStr = "";
          if (hour != 0) {
            timeStr = timeStr + String.format("%02d:", hour);
          }
          timeStr = timeStr + String.format("%02d:%02d", min, sec);
          timerText.setText(timeStr);

          if (!puzzle.validate()) {
            timeHandler.postDelayed(this, 0);
          }
        }
      };

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_solving);

    puzzle = (SudokuPuzzle) getIntent().getSerializableExtra(SudokuPuzzle.EXTRA_PUZZLE);
    highScore = (HighScore) getIntent().getSerializableExtra(HighScore.EXTRA_HIGH_SCORE);

    if (puzzle.isEasy()) {
      getActionBar()
          .setBackgroundDrawable(getResources().getDrawable(R.drawable.green_action_bar, null));
      getActionBar().setTitle(R.string.level_easy);
    } else if (puzzle.isMedium()) {
      getActionBar()
          .setBackgroundDrawable(getResources().getDrawable(R.drawable.red_action_bar, null));
      getActionBar().setTitle(R.string.level_medium);
    } else if (puzzle.isAdvance()) {
      getActionBar()
          .setBackgroundDrawable(getResources().getDrawable(R.drawable.blue_action_bar, null));
      getActionBar().setTitle(R.string.level_advance);
    } else if (puzzle.isMaster()) {
      getActionBar()
          .setBackgroundDrawable(getResources().getDrawable(R.drawable.yellow_action_bar, null));
      getActionBar().setTitle(R.string.level_master);
    } else if (puzzle.isLegendary()) {
      getActionBar()
          .setBackgroundDrawable(getResources().getDrawable(R.drawable.grey_action_bar, null));
      getActionBar().setTitle(R.string.level_legendary);
    }

    timerText = (TextView) findViewById(R.id.timer_text);
    startTime = SystemClock.uptimeMillis() - puzzle.getTime();
    time = puzzle.getTime();

    timeHandler.postDelayed(updateTimerThread, 0);

    updateGrid();
    updateInput();
  }

  @Override
  protected void onPause() {
    super.onPause();

    puzzle.setTime(time);

    try {
      FileOutputStream gridFileOutput = openFileOutput("puzzle.grid", MODE_PRIVATE);
      ObjectOutputStream gridObjectOutput = new ObjectOutputStream(gridFileOutput);

      if (puzzle.validate()) {
        deleteFile("puzzle.grid");
      } else {
        gridObjectOutput.writeObject(puzzle);
      }

      gridFileOutput.close();
      gridObjectOutput.close();
    } catch (Exception e) {
      e.printStackTrace();
    }

    try {
      FileOutputStream highScoreFileOutput = openFileOutput("highScore.hs", MODE_PRIVATE);
      ObjectOutputStream highScoreObjectOutput = new ObjectOutputStream(highScoreFileOutput);

      highScoreObjectOutput.writeObject(highScore);

      highScoreFileOutput.close();
      highScoreObjectOutput.close();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    getMenuInflater().inflate(R.menu.menu_solving, menu);
    return super.onCreateOptionsMenu(menu);
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    switch (item.getItemId()) {
      case R.id.surrender:
        // gridFragment.showSolution(puzzle);
        puzzle.surrender();
        updateGrid();
        updateInput();
        return true;
      case R.id.reset:
        puzzle.reset();
        updateGrid();
        updateInput();
        return true;
      default:
        return super.onOptionsItemSelected(item);
    }
  }

  public void updateGrid() {
    gridFragment = new GridFragment();
    gridFragment.setGrid(puzzle);

    FragmentTransaction ft = getFragmentManager().beginTransaction();
    ft.replace(R.id.grid_container, gridFragment);
    ft.commit();
  }

  public void updateInput() {
    input = new InputFragment();

    // change pen/pencil icon
    if (puzzle.isPenMode()) {
      input.penMode();
    } else {
      input.pencilMode();
    }

    // change color icon
    input.setColor(puzzle.getColor());

    // update number keys
    SudokuCell cell = puzzle.getSelectedCell();
    if ((cell != null)
        && ((cell.hasPencilMark() && !puzzle.isPenMode())
            || (!cell.hasPencilMark() && puzzle.isPenMode()))) {
      input.showState(cell);
    }

    FragmentTransaction ft = getFragmentManager().beginTransaction();
    ft.replace(R.id.input_container, input);
    ft.commit();
  }

  public void cellSelected(View view) {
    CellFragment cellFragment = (CellFragment) view.getTag();
    int row = cellFragment.getRow();
    int col = cellFragment.getColumn();

    if (puzzle.getSelectedCell() != puzzle.getCell(row, col)) {
      puzzle.selectCell(row, col);
    } else {;
      puzzle.unselectCell();
    }

    updateInput();
    updateGrid();
  }

  public void penSelected(View view) {
    if (puzzle.isPenMode()) {
      puzzle.pencilMode();
    } else {
      puzzle.penMode();
    }

    updateInput();
  }

  public void numberSelected(View view) {
    int val = (Integer) view.getTag();
    SudokuCell cell = puzzle.getSelectedCell();

    if (cell != null) {
      if (puzzle.isPenMode()) {
        cell.setColor(puzzle.getColor());
        cell.setValue(val);
      } else {
        cell.setPencilColor(val, puzzle.getColor());
        cell.pencilMark(val);
      }

      if (puzzle.validate()) {
        puzzle.setTime(time);
        puzzle.surrender();
        
        if (highScore.examine(puzzle)) {
          Toast.makeText(this, R.string.new_high_score, Toast.LENGTH_LONG).show();
        } else {
          Toast.makeText(this, R.string.good_job, Toast.LENGTH_LONG).show();
        }
      }

      updateInput();
      updateGrid();
    }
  }

  public void eraserSelected(View view) {
    SudokuCell cell = puzzle.getSelectedCell();

    if (cell != null) {
      cell.setValue(0);
      updateInput();
      updateGrid();
    }
  }

  public void colorSelected(View view) {
    SudokuColor color = (SudokuColor) view.getTag();

    if (color.equals(SudokuColor.GREY)) {
      puzzle.setColor(SudokuColor.RED);
    } else if (color.equals(SudokuColor.RED)) {
      puzzle.setColor(SudokuColor.YELLOW);
    } else if (color.equals(SudokuColor.YELLOW)) {
      puzzle.setColor(SudokuColor.GREEN);
    } else if (color.equals(SudokuColor.GREEN)) {
      puzzle.setColor(SudokuColor.BLUE);
    } else if (color.equals(SudokuColor.BLUE)) {
      puzzle.setColor(SudokuColor.GREY);
    }

    updateInput();
  }
}
