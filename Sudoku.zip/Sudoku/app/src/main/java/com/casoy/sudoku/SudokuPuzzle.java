package com.casoy.sudoku;

import java.io.Serializable;
import java.util.Random;
import java.util.ArrayList;

public class SudokuPuzzle extends SudokuGrid implements Serializable {
  private final static long serialVersionUID = 1L;
  private Level level;
  private String levelName = "";
  private int minimumBound;
  private int givenCount;
  private int currentGiven = 81;
  private SudokuGrid puzzle;
  
  private static final String levelNameEasy = "easy";
  private static final String levelNameMedium = "medium";
  private static final String levelNameAdvance = "advance";
  private static final String levelNameMaster = "master";
  private static final String levelNameLegendary = "legendary";

  public final static String EXTRA_PUZZLE = "extra_puzzle";
  public enum Level {
    EASY,
    MEDIUM,
    ADVANCE,
    MASTER,
    LEGENDARY
  }

  public SudokuPuzzle(Level level) {
    Random generator = new Random();
    randomGrid();
    switch (level) {
      case EASY:
        minimumBound = 5;
        givenCount = generator.nextInt(10) + 46;
        levelName = levelNameEasy;
        break;
      case MEDIUM:
        minimumBound = 4;
        givenCount = generator.nextInt(11) + 36;
        levelName = levelNameMedium;
        break;
      case ADVANCE:
        minimumBound = 3;
        givenCount = generator.nextInt(4) + 32;
        levelName = levelNameAdvance;
        break;
      case MASTER:
        minimumBound = 2;
        givenCount = generator.nextInt(4) + 28;
        levelName = levelNameMaster;
        break;
      case LEGENDARY:
        minimumBound = 0;
        givenCount = generator.nextInt(6) + 22;
        levelName = levelNameLegendary;
        break;
    }
    
    globalRandomizing();

    puzzle = clone();
  }

  public void reset() {
    for (int row = 0; row < 9; row++) {
      for (int col = 0; col < 9; col++) {
        getCell(row, col).setValue(puzzle.getCell(row, col).getValue());
      }
    }
  }
  
  public void surrender() {
    reset();
    solve();
    puzzle = clone();
    unselectCell();
  }

  public boolean dig(SudokuCell cell) {
    if (cell.getValue() != 0 && cell.canBeDig(minimumBound) && currentGiven > givenCount) {
      cell.setValue(0);
      currentGiven--;

      if (currentGiven == givenCount) {
        return true;
      } else {
        return false;
      }
    } else {
      return false;
    }
  }

  public boolean globalRandomizing() {
    ArrayList<SudokuCell> cellList = new ArrayList<SudokuCell>(81);

    for (int row = 0; row < 9; row++) {
      for (int col = 0; col < 9; col++) {
        cellList.add(getCell(row, col));
      }
    }

    Random generator = new Random();
    while (!cellList.isEmpty()) {
      SudokuCell cell = cellList.remove(generator.nextInt(cellList.size()));
      if(dig(cell)) {
        return true;
      }
    }
    
    return false;
  }

  public SudokuGrid getPuzzle() {
    return puzzle;
  }

  public Level getLevel() {
    return level;
  }
  
  public String getLevelName() {
    return levelName;
  }
  
  public boolean isEasy() {
    return levelName.equals(levelNameEasy);
  }
  
  public boolean isMedium() {
    return levelName.equals(levelNameMedium);
  }
  
  public boolean isAdvance() {
    return levelName.equals(levelNameAdvance);
  }
  
  public boolean isMaster() {
    return levelName.equals(levelNameMaster);
  }
  
  public boolean isLegendary() {
    return levelName.equals(levelNameLegendary);
  }
}
