package com.casoy.sudoku;

import android.app.Activity;
import android.os.Bundle;

public class AboutUsActivity extends Activity {
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_about_us);
    getActionBar()
        .setBackgroundDrawable(getResources().getDrawable(R.drawable.red_action_bar, null));
  }
}
