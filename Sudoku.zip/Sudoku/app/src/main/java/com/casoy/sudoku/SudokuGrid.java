package com.casoy.sudoku;

import java.io.Serializable;
import java.util.Random;
import java.util.ArrayList;

public class SudokuGrid implements Serializable {
  private final static long serialVersionUID = 1L;
  private SudokuCell[][] cells;
  private SudokuRow[] rows;
  private SudokuColumn[] columns;
  private SudokuBlock[][] blocks;
  private SudokuCell selectedCell;
  private boolean penMode = true;
  private SudokuColor color = SudokuColor.GREY;
  private long time;

  public SudokuGrid() {
    cells = new SudokuCell[9][9];
    rows = new SudokuRow[9];
    columns = new SudokuColumn[9];
    blocks = new SudokuBlock[3][3];

    for (int i = 0; i < 9; i++) {
      rows[i] = new SudokuRow();
      rows[i].setNumber(i);
      
      columns[i] = new SudokuColumn();
      columns[i].setNumber(i);
      
      blocks[i / 3][i % 3] = new SudokuBlock();
    }

    for (int row = 0; row < 9; row++) {
      for (int col = 0; col < 9; col++) {
        SudokuCell cell = new SudokuCell();

        cells[row][col] = cell;
        rows[row].addCell(cell);
        columns[col].addCell(cell);
        blocks[row / 3][col / 3].addCell(cell);
      }
    }
  }

  public SudokuCell getCell(int row, int col) {
    return cells[row][col];
  }

  public boolean validate() {
    for (int i = 0; i < 9; i++) {
      if (rows[i].validate() == false) {
        return false;
      }
      if (columns[i].validate() == false) {
        return false;
      }
      if (blocks[i / 3][i % 3].validate() == false) {
        return false;
      }
    }

    return true;
  }

  public boolean solve() {
    for (int row = 0; row < 9; row++) {
      for (int col = 0; col < 9; col++) {
        SudokuCell cell = getCell(row, col);

        // find cell with 0 value
        if (cell.getValue() == 0) {
          for (int i = 1; i <= 9; i++) {
            if (cell.isAvailable(i)) {
              cell.setValue(i);

              if (solve()) {
                return true;
              }
            }
          }

          cell.setValue(0);
          return false;
        }
      }
    }

    return true;
  }

  public boolean randomGrid() {
    Random generator = new Random();

    for (int row = 0; row < 9; row++) {
      for (int col = 0; col < 9; col++) {
        SudokuCell cell = getCell(row, col);

        // find cell with 0 value
        if (cell.getValue() == 0) {
          ArrayList<Integer> values = new ArrayList<Integer>();
          for (int i = 1; i <= 9; i ++) {
            values.add(i);
          }
          
          while (!values.isEmpty()) {
            int val = values.remove(generator.nextInt(values.size()));
            
            if (cell.isAvailable(val)) {
              cell.setValue(val);

              if (randomGrid()) {
                return true;
              }
            }
          }

          cell.setValue(0);
          return false;
        }
      }
    }

    return true;
  }

  @Override
  public SudokuGrid clone() {
    SudokuGrid copy = new SudokuGrid();

    for (int row = 0; row < 9; row++) {
      for (int col = 0; col < 9; col++) {
        copy.getCell(row, col).setValue(getCell(row, col).getValue());
      }
    }

    return copy;
  }

  public void selectCell(int row, int col) {
    selectedCell = getCell(row, col);
  }

  public SudokuCell getSelectedCell() {
    return selectedCell;
  }

  public void unselectCell() {
    selectedCell = null;
  }
  
  public boolean isPenMode() {
    return penMode;
  }
  
  public void penMode() {
    penMode = true;
  }
  
  public void pencilMode() {
    penMode = false;
  }
  
  public void setColor(SudokuColor color) {
    this.color = color;
  }
  
  public SudokuColor getColor() {
    return color;
  }
  
  public void setTime(long time) {
    this.time = time;
  }
  
  public long getTime() {
    return time;
  }
}
