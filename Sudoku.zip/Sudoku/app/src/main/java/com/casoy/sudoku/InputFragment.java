package com.casoy.sudoku;

import android.graphics.Color;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ImageView;

public class InputFragment extends Fragment {
  private SudokuColor color = SudokuColor.GREY;
  private boolean penMode = true;
  private SudokuColor[] numberColors = {
    SudokuColor.WHITE,
    SudokuColor.WHITE,
    SudokuColor.WHITE,
    SudokuColor.WHITE,
    SudokuColor.WHITE,
    SudokuColor.WHITE,
    SudokuColor.WHITE,
    SudokuColor.WHITE,
    SudokuColor.WHITE
  };

  @Override
  public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstaceState) {
    return inflater.inflate(R.layout.fragment_input, container, false);
  }

  @Override
  public void onStart() {
    super.onStart();

    View view = getView();

    if (view != null) {
      TextView[] keys = {
        (TextView) view.findViewById(R.id.key1),
        (TextView) view.findViewById(R.id.key2),
        (TextView) view.findViewById(R.id.key3),
        (TextView) view.findViewById(R.id.key4),
        (TextView) view.findViewById(R.id.key5),
        (TextView) view.findViewById(R.id.key6),
        (TextView) view.findViewById(R.id.key7),
        (TextView) view.findViewById(R.id.key8),
        (TextView) view.findViewById(R.id.key9)
      };

      for (int i = 0; i < 9; i++) {
        keys[i].setTextColor(Color.parseColor(numberColors[i].getHex()));
        keys[i].setTag(i+1);
      }

      ImageView colorSelector = (ImageView) view.findViewById(R.id.color_selector);
      colorSelector.setImageResource(color.getShapeId());
      colorSelector.setTag(color);

      ImageView penToggle = (ImageView) view.findViewById(R.id.pen_toggle);
      if (!penMode) {
        penToggle.setImageResource(R.drawable.pencil);
      }
    }
  }

  public void setNumberColor(int num, SudokuColor color) {
    numberColors[num - 1] = color;
  }

  public void setColor(SudokuColor color) {
    this.color = color;
  }

  public void penMode() {
    penMode = true;
  }

  public void pencilMode() {
    penMode = false;
  }

  public void showState(SudokuCell cell) {
    if (cell.hasPencilMark()) {
      for (int i = 1; i <= 9; i++) {
        if (cell.isMarkedAt(i)) {
          setNumberColor(i, cell.getPencilColor(i));
        }
      }
    } else if (cell.getValue() != 0) {
      setNumberColor(cell.getValue(), cell.getColor());
    }
  }
}
