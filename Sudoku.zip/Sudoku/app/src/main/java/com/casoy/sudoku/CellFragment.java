package com.casoy.sudoku;

import android.app.Fragment;

public abstract class CellFragment extends Fragment {
  private boolean selected = false;
  private int row;
  private int column;

  public void setRow(int row) {
    this.row = row;
  }

  public void setColumn(int column) {
    this.column = column;
  }

  public void select() {
    selected = true;
  }

  public int getRow() {
    return row;
  }

  public int getColumn() {
    return column;
  }
  
  public boolean isSelected() {
    return selected;
  }
}
