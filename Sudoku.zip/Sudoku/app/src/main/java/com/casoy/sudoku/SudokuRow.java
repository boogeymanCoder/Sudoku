package com.casoy.sudoku;

public class SudokuRow extends SudokuContainer {
  private final static long serialVersionUID = 1L;
  private int number;
  
  @Override
  public void addCell(SudokuCell cell) {
    super.addCell(cell);
    cell.setRow(this);
  }
  
  public void setNumber(int num) {
    number = num;
  }
  
  public int getNumber() {
    return number;
  }
}
