package com.casoy.sudoku;

import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class GridFragment extends Fragment {
  private BlockFragment[][] blockFragments;

  public GridFragment() {
    blockFragments = new BlockFragment[3][3];
    for (int i = 0; i < 3; i++) {
      for (int j = 0; j < 3; j++) {
        blockFragments[i][j] = new BlockFragment();
      }
    }
  }

  @Override
  public View onCreateView(
      LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    return inflater.inflate(R.layout.fragment_grid, container, false);
  }

  @Override
  public void onStart() {
    super.onStart();

    View view = getView();
    if (view != null) {

      FragmentTransaction ft = getFragmentManager().beginTransaction();
      ft.replace(R.id.block00, blockFragments[0][0]);
      ft.replace(R.id.block01, blockFragments[0][1]);
      ft.replace(R.id.block02, blockFragments[0][2]);
      ft.replace(R.id.block10, blockFragments[1][0]);
      ft.replace(R.id.block11, blockFragments[1][1]);
      ft.replace(R.id.block12, blockFragments[1][2]);
      ft.replace(R.id.block20, blockFragments[2][0]);
      ft.replace(R.id.block21, blockFragments[2][1]);
      ft.replace(R.id.block22, blockFragments[2][2]);
      ft.commit();

      for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
          blockFragments[i][j].setRow(i);
          blockFragments[i][j].setColumn(j);
        }
      }
    }
  }

  public void pencilMark(int row, int col, int num) {
    blockFragments[row / 3][col / 3].pencilMark(row % 3, col % 3, num);
  }

  /*public void setVal(int row, int col, int val) {
    blockFragments[row / 3][col / 3].setVal(row % 3, col % 3, val);
  }*/

  public void setBlankCell(int row, int col, int val, SudokuColor color) {
    blockFragments[row / 3][col / 3].setBlankCell(row % 3, col % 3, val, color);
  }

  public void setGiven(int row, int col, int val) {
    blockFragments[row / 3][col / 3].setGiven(row % 3, col % 3, val);
  }

  public void setGrid(SudokuPuzzle puzzle) {
    for (int row = 0; row < 9; row++) {
      for (int col = 0; col < 9; col++) {
        int givenVal = puzzle.getPuzzle().getCell(row, col).getValue();

        if (givenVal != 0) {
          setGiven(row, col, givenVal);
        } else if (puzzle.getCell(row, col).hasPencilMark()) {
          for (int i = 1; i <= 9; i++) {

            if (puzzle.getCell(row, col).isMarkedAt(i)) {
              setPencilColor(row, col, i, puzzle.getCell(row, col).getPencilColor(i));
              pencilMark(row, col, i);
            }
          }
        } else {
          int answerVal = puzzle.getCell(row, col).getValue();
          SudokuColor answerColor = puzzle.getCell(row, col).getColor();

          /*setColor(row, col, answerColor);
          setVal(row, col, answerVal);*/

          setBlankCell(row, col, answerVal, answerColor);
        }
      }
    }

    SudokuCell cell = puzzle.getSelectedCell();
    if (cell != null) {
      select(cell.getRowNumber(), cell.getColumnNumber());
    }
  }

  public void setPencilColor(int row, int col, int num, SudokuColor color) {
    blockFragments[row / 3][col / 3].setPencilColor(row % 3, col % 3, num, color);
  }

  /*public void setColor(int row, int col, SudokuColor color) {
    blockFragments[row / 3][col / 3].setColor(row % 3, col % 3, color);
  }*/

  public void select(int row, int col) {
    blockFragments[row / 3][col / 3].select(row % 3, col % 3);
  }
}
